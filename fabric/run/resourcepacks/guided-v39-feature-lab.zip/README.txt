Guided V39 feature lab
Install as a resource pack.
/give @s guided:guide_book[guided:book_id="guided_showcase39:browser"]
/give @s guided:guide_book[guided:book_id="guided_showcase39:manual"]
/give @s guided:guide_book[guided:book_id="guided_showcase39:pamphlet"]
/give @s guided:guide_book[guided:book_id="guided_showcase39:postcard"]
/give @s guided:guide_book[guided:book_id="guided_showcase39:network"]
Conditions: true/and_pass/or_pass/not_pass visible; false and fail entries absent. Grant/revoke minecraft:story/mine_diamond, reopen or press R. Drop and pick up a diamond, open vanilla Statistics to sync, then reopen book. Test U on a hovered entry and restart for persistence. No overflow tests.
